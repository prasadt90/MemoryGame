//
//  MGConstants.swift
//  MemoryGame
//
//  Created by sai on 15/01/16.
//  Copyright © 2016 sai. All rights reserved.
//

import Foundation

//=============================================================================
// MARK: - Flickr Constants

let kFlickrAPIKey = "9f1d9fef5427e1a3407b387a4f8982a3"
let kFlickrSecret = "0358cb21c558f9d1"
let kImageSearch  = "flowers"

let knumberOfImagesPerPage  = 9
let kRequestFormat          = "json"


let kImageIdKey       = "id"
let kImageOwnerKey    = "owner"
let kImageSecretKey   = "secret"
let kImageServerKey   = "server"
let kImageFarmKey     = "farm"
let kImageTitle       = "title"
let kPhotosKey        = "photos"
let kPhotoKey         =  "photo"

let kCollectionImageIdentifier = "CollectionImageCell"