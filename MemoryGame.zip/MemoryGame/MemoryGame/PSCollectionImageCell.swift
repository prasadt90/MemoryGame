//
//  PSCollectionImageCell.swift
//  MemoryGame
//
//  Created by sai on 14/01/16.
//  Copyright © 2016 sai. All rights reserved.
//

import UIKit

class PSCollectionImageCell: UICollectionViewCell {
    
    @IBOutlet weak var displayImageView: UIImageView!

}
