//
//  ViewController.swift
//  MemoryGame
//
//  Created by sai on 13/01/16.
//  Copyright © 2016 sai. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {
    
    var responseDictionary : NSDictionary = [:]
    var responseImagesArray = [ImageDetails]()
    var round = 10
    var noOftry = 0
    var testMode:Bool = true;
    var randomArray:[Int]=[]
    var imageArray:[UIImage]=[]
    var selectedIndex:Int = 0
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    @IBOutlet weak var displayImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let alertController = UIAlertController(title:"Guess the Image", message: "Remember the indexes of images displayed to you and guess the index correctly to win the GAME", preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.Cancel, handler:nil)
        alertController.addAction(okAction)
        self.presentViewController(alertController, animated: false, completion: nil)
        self.displayImageView.layer.borderWidth = 2.0
        self.displayImageView.layer.borderColor = UIColor.blackColor().CGColor
        self.performSelectorInBackground(Selector("loadFlickrImages"), withObject: nil)
    }
    
    func loadFlickrImages(){
        let urlString = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=\(kFlickrAPIKey)&tags=\(kImageSearch)&safe_search=1&per_page=\(knumberOfImagesPerPage)&format=\(kRequestFormat)&nojsoncallback=1"
        
        let flickrUrl: NSURL = NSURL(string: urlString)!
        let session = NSURLSession.sharedSession()
        let sessionTask = session.dataTaskWithURL(flickrUrl, completionHandler: {
            (data, response, error) -> Void in
            do {
                if data == nil {
                    return
                }
                else{
                    do {
                        let jsonData = try NSJSONSerialization.JSONObjectWithData(data!, options: .MutableContainers) as! NSDictionary
                        self.responseDictionary = (jsonData.objectForKey(kPhotosKey) as? NSDictionary)!
                        print(self.responseDictionary[kPhotoKey]!)
                        
                        if let customerArray = self.responseDictionary[kPhotoKey]! as? NSArray {
                            for imageDetail in customerArray {
                                let imageObject = ImageDetails(imageID: (imageDetail[kImageIdKey] as? String)!,
                                    imageOwner: (imageDetail[kImageOwnerKey] as? String)!,
                                    imageSecret: (imageDetail[kImageSecretKey] as? String)!,
                                    imageServer: (imageDetail[kImageServerKey] as? String)!,
                                    imageFarm: imageDetail[kImageFarmKey] as! Int,
                                    imageTitle: ("\(imageDetail[kImageTitle])"))
                                
                                self.responseImagesArray.append(imageObject)
                            }
                        }
                        
                        self.createImageArray()
                        
                    } catch {
                        print("***** JSON PARSING ERROR *****")
                    }
                }
            }
        })
        sessionTask.resume()
    }
    
    
    func createImageArray(){
        self.imageArray = []
        for obj:ImageDetails in responseImagesArray{
            let img = self.imageFor(obj)
            imageArray.append(img!)
        }
        dispatch_async(dispatch_get_main_queue(), {
        
             self.imageCollectionView.reloadData()
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        self.imageCollectionView.reloadData()
        self.performSelector(Selector("startTest"), withObject: nil, afterDelay: 0)
    }

    //MARK: UICollectionView DataSource Methods
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return imageArray.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell{
        var cell:PSCollectionImageCell? = nil
        cell = collectionView.dequeueReusableCellWithReuseIdentifier("CollectionImageCell", forIndexPath: indexPath) as? PSCollectionImageCell
        if cell == nil{
            cell = PSCollectionImageCell()
        }
        
        if let createdCell = cell{
            if testMode{
                createdCell.displayImageView.image = UIImage(named: "test")
            }else{
                let image = self.imageArray[randomArray[indexPath.row]]
                createdCell.displayImageView.image = image
            }
        }
        return cell!;
    }
    
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize{
            
            let width=(collectionView.frame.size.width-3*10)/3;
            let height=(collectionView.frame.size.height-3*10)/3;
            return CGSizeMake(width, height);
    }
    
    
    //MARK: UICollectionView Delegate Methods
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if self.testMode{
            if indexPath.row == self.selectedIndex{
                print("************ SUCCESS! NEXT ROUND *************")
                let alertController = UIAlertController(title: noOftry == 0 ? "EXCELLENT JOB!" : "GOOD", message: noOftry == 0 ? "YOU FINISHED IN SINGLE SHOT!" : "BUT YOU TOOK \(noOftry+1) CHANCES", preferredStyle: UIAlertControllerStyle.Alert)
                let okAction = UIAlertAction(title: noOftry == 0 ? "Thank you!" : "OK! Let me try again", style: UIAlertActionStyle.Cancel, handler: { (Void) -> Void in
                    if self.round < 2{
                        self.round = 1
                    }else{
                        self.round = self.round - 1
                    }
                    
                    print("delay :\(self.round)")
                    self.startTest()
                })
                alertController.addAction(okAction)
                self.presentViewController(alertController, animated: false, completion: nil)
            }else{
                noOftry++
                 let alertController = UIAlertController(title: "", message: "FAILED! TRY AGAIN", preferredStyle: UIAlertControllerStyle.Alert)
                let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.Cancel, handler:nil)
                alertController.addAction(okAction)
                self.presentViewController(alertController, animated: false, completion: nil)
               // print("************ FAILED! TRY AGAIN *************")
            }
        }else{
            //print("************ WATCH THE IMAGES *************")
        }
        
    }
    
    
    func startTest(){
        self.testMode = false
        noOftry = 0
        self.imageCollectionView.reloadData()
        self.displayImageView.image = UIImage(named: "test")
        self.prepareRandomArray()
        self.performSelector(Selector("hideImage"), withObject: nil, afterDelay: Double(round))
    }
    
    func hideImage(){
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("hideImage"), object: nil)
        self.testMode = true
        self.imageCollectionView.reloadData()
        if self.imageArray.count>0{
        self.displayImageView.image = self.imageArray[randomArray[self.selectedIndex]]
        }
        else{
        self.performSelector(Selector("hideImage"), withObject: nil, afterDelay: Double(round))
        }
    }
    
    func prepareRandomArray(){
        var isArrayReady = false
        self.randomArray = []
        repeat{
            let nextDigit:Int = Int(arc4random_uniform(9))
            if !self.randomArray.contains(nextDigit){
                self.randomArray.append(nextDigit)
                isArrayReady = self.randomArray.count == 9 ? true : false
            }
        }while !isArrayReady
        self.selectedIndex = Int(arc4random_uniform(9))
        print("index : \(selectedIndex)")
    }
    
    
    @IBAction func restartAction(sender: AnyObject) {
        if self.testMode{
            self.startTest()
        }
    }
    
    func imageFor(photo:ImageDetails)->UIImage?{
        let photoUrl = "http://farm\(photo.imageFarm).static.flickr.com/\(photo.imageServer)/\(photo.imageID)_\(photo.imageSecret)_s.jpg"
       if let imgData = NSData(contentsOfURL: NSURL(string: photoUrl)!)
       {
        let img = UIImage(data: imgData)
        return img
        }
       else{
        return nil
        }
    }
}

