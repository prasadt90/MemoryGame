//
//  MGDataModel.swift
//  MemoryGame
//
//  Created by sai on 15/01/16.
//  Copyright © 2016 sai. All rights reserved.
//

import Foundation
import UIKit

// MARK: - =============
// MARK: - ImageDetails Model
class ImageDetails {
    var imageID       : String
    var imageOwner    : String
    var imageSecret   : String
    var imageServer   : String
    var imageFarm     : Int
    var imageTitle    : String
    init(imageID: String,imageOwner:String,imageSecret:String,imageServer:String,imageFarm:Int,imageTitle:String){
        self.imageID      = imageID
        self.imageOwner   = imageOwner
        self.imageSecret  = imageSecret
        self.imageServer  = imageServer
        self.imageFarm    = imageFarm
        self.imageTitle   = imageTitle
    }
}